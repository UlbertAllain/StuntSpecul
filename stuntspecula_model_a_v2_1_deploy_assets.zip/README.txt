StuntSpecula Model A V2.1 — classifier deployment assets

Copy these files into the repository `models/` directory:
- mobilenetv3_stunting_v2.onnx
- mobilenetv3_stunting_v2.onnx.data

The YuNet detector file is installed separately by:
  .\scripts\install-model-a.ps1

Reference files included:
- model_metadata.json
- onnx_parity.json
- quality_gate_config_v1.json

Important:
The ONNX file uses external weights. Do not deploy the .onnx without the
adjacent .onnx.data file.
